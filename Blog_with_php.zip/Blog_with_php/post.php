<?php include "included/header.php"; ?>

<?php
if(!isset($_GET['id']) || $_GET['id']==NULL)
{
	header("location:404.php");}
else{
	$id=$_GET['id'];
}
?>
    <div class="content template clear">

        <div class="mainbody clear">
            
				<?php
				$query= "select * from tbl_post where id= '$id' ";
				$post=$db->select($query);
        if($post){
            while($result=$post->fetch_assoc())
            {
                
            
        ?>
               <div class="samepost clear">
            <h2><a hre="post.php ?id=<?php echo $result['id'];?>"> <?php echo $result['title'];?></a> </h2>
            
            <h4> <?php echo $fm->formatdate($result['date']); ?>, By <?php echo $result['author'];?> </h4>
           
            <img src="admin/<?php echo $result['image'];?>" alt="Image"/>
             <?php echo $result['body'];?>
			
			<?php
			}} else{
				header("location:404.php");	
			}
			?>
            <div class="relatedpost clear">
					<h2>Related Articles</h2>
					

					<a href="#"><img src="img/post1.jpg" alt="post image"/></a>
					<a href="#"><img src="img/post1.jpg" alt="post image"/></a>
					<a href="#"><img src="img/post1.jpg" alt="post image"/></a>
					<a href="#"><img src="img/post1.jpg" alt="post image"/></a>
					<a href="#"><img src="img/post1.jpg" alt="post image"/></a>
					<a href="#"><img src="img/post1.jpg" alt="post image"/></a>
				</div>
        </div>
    
   
</div>

    <?php include 'included/sidebar.php'; ?>
    <?php include 'included/footer.php'; ?>