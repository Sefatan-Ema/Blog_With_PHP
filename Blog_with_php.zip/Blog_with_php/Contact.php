<?php include "included/header.php"; ?>
<?php
		if($_SERVER['REQUEST_METHOD'] == "POST"){
			$fname=$fm->validation($_POST['firstname']);
			$lname=$fm->validation($_POST['lastname']);
			$email=$fm->validation(($_POST['email']));
            $body=$fm->validation($_POST['body']);
			
            $fname=mysqli_real_escape_string($db->link, $fname);
			$lname=mysqli_real_escape_string($db->link, $lname);
			$email=mysqli_real_escape_string($db->link, $email);
            $body=mysqli_real_escape_string($db->link, $body);
            $error="";
            if(empty($fname)){
                $error=" First name must not be empty!";

            }elseif(empty($fname)) {
                $error=" Last name must not be empty!";
            }
            elseif(empty($email)) {
                $error=" Email must not be empty!";
            }
            elseif((filter_var($email, FILTER_VALIDATE_EMAIL))) {
                $error=" Invalid Email !";
            }
            elseif(empty($body)) {
                $error=" Body must not be empty!";
            }
            else {
                $query = "INSERT INTO tbl_contact(firstname,lastname, email, body) 

                VALUES('$fname','$lname', '$email' ,'$body')";
 $inserted_rows = $db->insert($query);
 if ($inserted_rows) {
  
  $msg=" Massage Send  Successfully.";
            }
            
        }
    }  
?>

    <div class="content template clear">

        <div class="mainbody clear">
            <div class=" samepost about ">
                <h2>Contact us</h2>
              <?php  if(isset($error)){
                    echo "<span style='color:red' > $error </span>";
                }
                elseif(isset($msg)){
                    echo "<span style='color:red' > $msg </span>";
                } ?>
              
                <form action="" method="POST">
                <table>
                    <tr>
                        <td>Your First Name:</td>
                        <td>
                            <input type="text" name="firstname" placeholder="Enter first name" />
                        </td>
                    </tr>
                    <tr>
                        <td>Your Last Name:</td>
                        <td>
                            <input type="text" name="lastname" placeholder="Enter Last name" />
                        </td>
                    </tr>

                    <tr>
                        <td>Your Email Address:</td>
                        <td>
                            <input type="email" name="email" placeholder="Enter Email Address" />
                        </td>
                    </tr>
                    <tr>
                        <td>Your Message:</td>
                        <td>
                            <textarea name="body" ></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                        <button type="submit" class="btn btn-primary">Submit</button>
                            
                        </td>
                    </tr>
                </table>

                </form>
            </div>

        </div>

        
<?php include 'included/sidebar.php'; ?>
    <?php include 'included/footer.php'; ?>