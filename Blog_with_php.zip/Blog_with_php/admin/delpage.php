<?php  include "../lib/session.php"; 
Session:: checkSession();?>
<?php  
include '../config/config.php';  
include '../lib/Database.php';
include '../helpers/format.php';
$db=new database() ;

?>
 <?php
if(!isset($_GET['delpage'])|| $_GET['delpage']==null){
    header("location:postlist.php");
}
else{
    $id=$_GET['delpage'];
    
   
    $delquery="delete from tbl_page where id= $id";
    $delpost= $db->delete($delquery);
    if($delpost){
        echo "<script>alert('Page deleted successfully.') </script>";
        header("location:postlist.php");
    }
    else{
        echo "<script>alert('Page  not deleted successfully.') </script>";
        header("location:index.php");
    }
    }

?>