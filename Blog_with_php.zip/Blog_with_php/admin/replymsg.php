<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php
if(!isset($_GET['msgid'])|| $_GET['msgid']==null){
    header("location:inbox.php");
}
else{
    $id=$_GET['msgid'];
}
?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Reply message</h2>
                <?php
                if($_SERVER['REQUEST_METHOD'] == "POST"){
                    $to=$fm->validation($_POST['to']);
                    $from=$fm->validation(($_POST['from']));
                    $subject=$fm->validation($_POST['subject']);
			        $body=$fm->validation(md5($_POST['body']));
                    $sendmail=mail($to,$from, $subject, $body);
                    if($sendmail){
                        echo "<span class='success'>Message Send Successfully.
                </span>";
               } else {
                echo "<span class='error'>Something Went Wrong !</span>";
               }
                    
                
                
              
            }

                ?>
                <div class="block">               
                 <form action="" method="POST" >
                 <?php
					$query="select * from tbl_contact where id='$id' ";
					$msg= $db->select($query);
					if($msg){
						
						while($result=$msg->fetch_assoc())
						{
							
						
					
						?>
                    <table class="form">
                       
                       
                     
                        <tr>
                    
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>To</label>
                            </td>
                            <td>
                                <input type="text" readonly  name="to"  value="<?php echo $result['email'];?>" class="medium" />
                            </td>
                           
                        </tr>
                        <tr>
                            <td>
                                <label>From</label>
                            </td>
                            <td>
                                <input type="text"  name="from" placeholder="Enter Your Email Address." class="medium" />
                            </td>
                        </tr>
                        <tr>
                    
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Subject</label>
                            </td>
                            <td>
                                <input type="text" name="subject" placeholder="Enter Your Email Subject." class="medium" />
                            </td>
                            
                        </tr>
                        <tr>
                    
                            <td >
                                <label>Message</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="body"> <?php echo $result['body'];?> </textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                               
                            </td>
                            <td>
                             <input type="submit" name="submit" value="Send" />
                            </td>
            </tr>
                    </table>
                    <?php
                        }}
                        ?>
                    </form>
                </div>
            </div>
        </div>
       
 <!-- Load TinyMCE -->
 <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
		<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
		    setSidebarHeight();
        });
    </script>
    <!-- /TinyMCE -->
    <?php include 'inc/footer.php'; ?>
