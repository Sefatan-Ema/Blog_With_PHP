<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New User</h2>
               <div class="block copyblock"> 
            <?php  
            if($_SERVER['REQUEST_METHOD'] == "POST"){
                $username=$fm->validation($_POST['username']);
                $password=$fm->validation(md5($_POST['password']));
                $role=$fm->validation(($_POST['role']));
                $email=$fm->validation(($_POST['email']));
    
                $username=mysqli_real_escape_string($db->link, $username);
                $password=mysqli_real_escape_string($db->link, $password);
                $email=mysqli_real_escape_string($db->link, $email);
			$role=mysqli_real_escape_string($db->link, $role);
			
            if(empty($username) || empty($password)|| empty($role) || empty($email)){
                echo "<span class='error'> Empty Feild not allowed</span>";
            }
            else{
            $query="select * from tbl_user where email='$email' limit 1";
					$user= $db->select($query);
                    if($user != false){
                        echo "<span class='error'> Email Already Exists</span>";
                  
                              }
            else{
			$query="insert into  tbl_user(username,password,email,role) values('$username','$password','$email','$role') ";
			$userinsert=$db->insert($query);
            if($userinsert){
                echo "<span class='success'> User created Sucessfully</span>";
            }
            else{
                echo "<span class='error'> User Not created</span>";
            }
        }  
  } } ?>
                 <form action="" method="POST">
                    <table class="form">					
                        <tr>
                            <td> 
                                <label>Username</label>
                            </td>
                            <td>
                                <input type="text"  name="username" placeholder="Enter Your Name" name="name" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td> 
                                <label>Password</label>
                            </td>
                            <td>
                                <input type="text"  name="password" placeholder="Enter Password" name="name" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td> 
                                <label>Email</label>
                            </td>
                            <td>
                                <input type="email"  name="email" placeholder="Enter your email" name="name" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td> 
                                <label>Role</label>
                            </td>
                            <td>
                                <select  id="select" name="role" > 
                                <option >Select Role</option> 
                                
                                    <option value='1'>Admin</option> 
                                    <option value='2'>Editor</option> 
                                    <option value='3'>Author</option> 
                                    
                                 </select>
                            </td>
                        </tr>
						<tr> 
                        <td>
</td>
                            <td>
                                <input type="submit" name="submit" Value="Create" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
        <?php include 'inc/footer.php'; ?>