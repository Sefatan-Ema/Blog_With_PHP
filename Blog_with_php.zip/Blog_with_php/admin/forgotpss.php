<?php
include '../lib/session.php';
session::checkLogin();?>
<?php  
include '../config/config.php';  
include '../lib/Database.php';
include '../helpers/format.php';
$db=new database() ;
$fm=new format() ;
?>
<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Password Recovery</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<body>
<div class="container">
	<section id="content">
	<?php
		if($_SERVER['REQUEST_METHOD'] == "POST"){
			$email=$fm->validation($_POST['email']);
			
			$email=mysqli_real_escape_string($db->link, $email);
            if((!filter_var($email, FILTER_VALIDATE_EMAIL))) {
                echo " Invalid Email !";
            }
            else {
                
                $query="select * from tbl_user where email='$email' limit 1";
                $user= $db->select($query);
                if($user != false){
                    while($result=$user->fetch_assoc()){
                        $id=$result['id'];
                        $username=$result['username'];
                        
                    }
                    $txt=substr($email, 0,3);
                    $rand=rand(10000,99999);
                    $new="$txt$rand";
                    $password=md5($new);
                    $query=" Update tbl_user
            SET 
              password='$password'
            where id='$id'";
			$updated=$db->update($query);
            $to="$email";
            $from="ema.cse6.bu@gmail.com";
            $body ="Your Username is:".$username; 
            $subject="Your new pass";
            $sendmail=mail($to,$from, $subject, $body);
                }
			
			else{
				echo "<span style='color:red; font-size:25px';>Email doesnot Exist!</span>";
			}
		}} 
		?>
	
		<form action="login.php" method="POST">
			<h1>Password Recovery</h1>

			
			
			<div>
				<input type="email" placeholder="email" required="" name="email"/>
			</div>
			<div>
				<input type="submit" value="Send via Mail" />
			</div>
		</form><!-- form -->
		<div class="button">
			<a href="login.php">Login</a>
		</div>
		<div class="button">
			<a href="#">Sefatan Sowda Ema</a>
		</div><!-- button -->
	</section><!-- content -->
</div><!-- container -->
</body>
</html>