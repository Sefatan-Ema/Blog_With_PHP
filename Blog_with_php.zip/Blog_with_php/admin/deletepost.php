<?php  include "../lib/session.php"; 
Session:: checkSession();?>
<?php  
include '../config/config.php';  
include '../lib/Database.php';
include '../helpers/format.php';
$db=new database() ;

?>
 <?php
if(!isset($_GET['postid'])|| $_GET['postid']==null){
    header("location:postlist.php");
}
else{
    $id=$_GET['postid'];
    
    $query="select *   from tbl_post where id ='$id'";
    $getpost=$db->select($query);
    if($getpost){
        while($delimg=$getpost->fetch_assoc()){
            $dellink=$delimg['image'];
            unlink($dellink);
        }
    }
    $delquery="delete from tbl_post where id= '$id'";
    $delpost= $db->delete($delquery);
    if($delpost){
        echo "<script>alert('Data deleted successfully.') </script>";
        header("location:postlist.php");
    }
    else{
        echo "<script>alert('Data  not deleted .') </script>";
        header("location:postlist.php");
    }
    }

?>