<?php include "included/header.php"; ?>
<?php
if(!isset($_GET['keyword']) || $_GET['keyword']==NULL)
{
	header("location:404.php");}
else{
	$search=$_GET['keyword'];
}
?>
<div class="content template clear">

<div class="mainbody clear">
<?php

$query= "select * from tbl_post where title like '%$search%' or body like '%$search%'";
$post=$db->select($query);
if($post){
    while($result=$post->fetch_assoc())
    {
        
    
?>

               <div class="samepost clear">
            <h2><a href="post.php?id=<?php echo $result['id'];?>"> <?php echo $result['title'];?></a> </h2>
            
            <h4> <?php echo $fm->formatdate($result['date']); ?>, By <?php echo $result['author'];?> <h4>
           
            <img src="admin/<?php echo $result['image'];?>" alt="Image">
            
            
            <?php echo $fm->txtshorten($result['body']);?>
            <div class="readmore">
            <a  href="post.php?id=<?php echo $result['id'];?>" >Read More </a>
            </div>
        </div>
        <?php }}

else{
    
?>
<p> Not Found</p>
<?php
}
?>
</div>
<?php include 'included/sidebar.php'; ?>
    <?php include 'included/footer.php'; ?>