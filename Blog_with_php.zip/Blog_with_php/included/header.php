<?php include "config/config.php"; ?>

<?php include "lib/Database.php"; ?>
<?php include "helpers/format.php"; ?>
<?php
$db= new Database();
$fm=new Format();

?>

<!DOCTYPE html>

<html>

<head> 
    <?php if(isset($_GET['pageid'])){
    $pagetitle=$_GET['pageid'];

                                $query="Select * from tbl_page where id='$pagetitle'";
                                $pages=$db->select($query);
                                if($pages)
                                {
                                    while($result=$pages->fetch_assoc())
                                    {
                                      ?> 
                                       <title><?php echo $result['name'] ; ?>-<?php echo TITLE ; ?></title>
                                   <?php }}}
                            elseif(isset($_GET['id'])){
                                $pagetitle=$_GET['id'];

                                $query="Select * from tbl_post where id='$pagetitle'";
                                $post=$db->select($query);
                                if($post)
                                {
                                    while($result=$post->fetch_assoc())
                                    {
                                      ?> 
                                       <title><?php echo $result['title'] ; ?>-<?php echo TITLE ; ?></title>
                                   <?php }}}
                                
                                 else { ?>

                                 <title> <?php echo $fm->title() ; ?>-<?php echo TITLE ; ?> </title>
                             <?php }   ?>
    
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="font-awesome-4.5.0/css/font-awesome.css">	
	<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />
	
	<script src="js/jquery.js" type="text/javascript"></script>
	<script src="js/jquery.nivo.slider.js" type="text/javascript"></script>

<script type="text/javascript">
$(window).load(function() {
	$('#slider').nivoSlider({
		effect:'random',
		slices:10,
		animSpeed:500,
		pauseTime:5000,
		startSlide:0, //Set starting Slide (0 index)
		directionNav:false,
		directionNavHide:false, //Only show on hover
		controlNav:false, //1,2,3...
		controlNavThumbs:false, //Use thumbnails for Control Nav
		pauseOnHover:true, //Stop animation while hovering
		manualAdvance:false, //Force manual transitions
		captionOpacity:0.8, //Universal caption opacity
		beforeChange: function(){},
		afterChange: function(){},
		slideshowEnd: function(){} //Triggers after all slides have been shown
	});
});
</script>

</head>

<body>
    <div class="header template clear">
        <div class="logo">
        <?php
                    $query="select * from title_slogan where id='1'";
                    $blog_title=$db->select($query);
                    if( $blog_title){
                        while($result= $blog_title->fetch_assoc()){
                    ?> 

            <img src="admin/<?php echo $result['logo'];?>" alt="Logo"/>
            <h2><?php echo $result['title'];?></h2>
            <h3><?php echo $result['slogan'];?></h3>
           
            <p><?php echo $result['inst'];?></p> 
            <?php
            }}
            ?>
        </div>
   
        <div class="social">
        <?php
                    $query="select * from tbl_social where id='1'";
                    $social=$db->select($query);
                    if( $social){
                        while($result= $social->fetch_assoc()){
                    ?>  
           
           <div class="icon clear">
				<a href="<?php echo $result['Fb'];?>" target="_blank"><i class="fa fa-facebook"></i></a>
				<a href="<?php echo $result['Tw'];?>" target="_blank"><i class="fa fa-twitter"></i></a>
				<a href="<?php echo $result['Ln'];?>" target="_blank"><i class="fa fa-linkedin"></i></a>
				<a href="<?php echo $result['Gg'];?>" target="_blank"><i class="fa fa-google-plus"></i></a>
			</div>
			
			
            <?php
            }}
            ?>	
        <div class="search clear">
            <form action="search.php" method="GET">                                                                                                                
            <input type="text"  name ="keyword" placeholder="Search Here"/>                           
            <input type="submit" name="submit" value="search"/>
        </form>
        </div>
            
        </div>
        </div>
        
    </div>

    <div class="menu template ">
   <?php $path=$_SERVER['SCRIPT_FILENAME'];
    $curpage=basename($path,'.php');
     ?>   <ul>
            <li><a 
            <?php if($curpage=='index'){
 echo 'id="active"';
            } ?>
         href="index.php">Home</a></li>
            <?php
                                $query="Select * from tbl_page";
                                $pages=$db->select($query);
                                if($pages)
                                {
                                    while($result=$pages->fetch_assoc())
                                    {

                                ?>
                                 <li><a  <?php if(isset($_GET['pageid']) && $_GET['pageid']){
                                  echo 'id="active"';
                                }  ?>
                                 href="page.php?pageid=<?php echo $result['id']; ?>"><?php echo $result['name']; ?></a></li>
                             <?php }} ?>
            
            
               
                
            
            <!-- <li><a href="#">Faculty</a></li> -->
            <li><a <?php if($curpage=='Contact'){
 echo 'id="active"';
            } ?> href="Contact.php">Contact Us</a></li>

        </ul>
    </div>