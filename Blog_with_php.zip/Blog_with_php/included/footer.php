</div>
    
    <div class="footer template clear">
        <div>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="Contact.php">Contact us</a></li>
            </ul>
        </div>
        <div class="cpy">
        <?php
                    $query="select * from  tbl_cpy where id='1'";
                    $cpyright=$db->select($query);
                    if($cpyright){
                        while($result= $cpyright->fetch_assoc()){
                    ?>        
            <p>&copy;<a style=" text-decoration:none" href="https://www.facebook.com/Sefatanema"><?php echo $result['note']; echo date('Y');?></a> || All Rights Reserved.</p>
            <p>Computer Science & Engineering </p>
            <p>Gmail:sefatanema@gmail.com </p>
            <?php    }}?>
        </div>

    </div>
    <div class="fixedicon clear">
    <?php
                    $query="select * from tbl_social where id='1'";
                    $social=$db->select($query);
                    if( $social){
                        while($result= $social->fetch_assoc()){
                    ?>  
		<a href="<?php echo $result['Fb'];?>"><img src="img/fix/fb.png" alt="Facebook"/></a>
		<a href="<?php echo $result['Tw'];?>"><img src="img/fix/tw.png" alt="Twitter"/></a>
		
		<a href="<?php echo $result['Ln'];?>"><img src="img/fix/lin.png" alt="LinkedIn"/></a>
        <a href="<?php echo $result['Gg'];?>"><img src="img/fix/gg.png" alt="Google"/></a>
        <!-- http://www.google.com -->
	</div>
 <?php
 }}?>
 


<script type="text/javascript">var scrolltotop={setting:{startline:100,scrollto:0,scrollduration:1e3,fadeduration:[500,100]},controlHTML:'<img src="https://lh3.googleusercontent.com/pw/AM-JKLVMrv8KCT5A0jeE8lBRZbyDzePQrmJXvx7JM8IRCL-YM9wioAIlzciMrij2krC1yRcAfRzjHlN35O1sS02mAfUP64ALFGs5Qh_DiWstkyXAf5QAzGuxHKo6C9-yZh9K6p7-LBBFql5k45NqvCpgqRtZ=s48-no" />',controlattrs:{offsetx:5,offsety:5},anchorkeyword:"#top",state:{isvisible:!1,shouldvisible:!1},scrollup:function(){this.cssfixedsupport||this.$control.css({opacity:0});var t=isNaN(this.setting.scrollto)?this.setting.scrollto:parseInt(this.setting.scrollto);t="string"==typeof t&&1==jQuery("#"+t).length?jQuery("#"+t).offset().top:0,this.$body.animate({scrollTop:t},this.setting.scrollduration)},keepfixed:function(){var t=jQuery(window),o=t.scrollLeft()+t.width()-this.$control.width()-this.controlattrs.offsetx,s=t.scrollTop()+t.height()-this.$control.height()-this.controlattrs.offsety;this.$control.css({left:o+"px",top:s+"px"})},togglecontrol:function(){var t=jQuery(window).scrollTop();this.cssfixedsupport||this.keepfixed(),this.state.shouldvisible=t>=this.setting.startline?!0:!1,this.state.shouldvisible&&!this.state.isvisible?(this.$control.stop().animate({opacity:1},this.setting.fadeduration[0]),this.state.isvisible=!0):0==this.state.shouldvisible&&this.state.isvisible&&(this.$control.stop().animate({opacity:0},this.setting.fadeduration[1]),this.state.isvisible=!1)},init:function(){jQuery(document).ready(function(t){var o=scrolltotop,s=document.all;o.cssfixedsupport=!s||s&&"CSS1Compat"==document.compatMode&&window.XMLHttpRequest,o.$body=t(window.opera?"CSS1Compat"==document.compatMode?"html":"body":"html,body"),o.$control=t('<div id="topcontrol">'+o.controlHTML+"</div>").css({position:o.cssfixedsupport?"fixed":"absolute",bottom:o.controlattrs.offsety,right:o.controlattrs.offsetx,opacity:0,cursor:"pointer"}).attr({title:"Scroll to Top"}).click(function(){return o.scrollup(),!1}).appendTo("body"),document.all&&!window.XMLHttpRequest&&""!=o.$control.text()&&o.$control.css({width:o.$control.width()}),o.togglecontrol(),t('a[href="'+o.anchorkeyword+'"]').click(function(){return o.scrollup(),!1}),t(window).bind("scroll resize",function(t){o.togglecontrol()})})}};scrolltotop.init();</script>

</body>

</html>