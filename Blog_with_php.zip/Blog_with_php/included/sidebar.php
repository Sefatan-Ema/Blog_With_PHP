<div class="sidebody clear">
<div class="semiside  clear">
                <h2>Category</h2>
                <ul><?php

$query= "select * from tbl_cate limit 5";
$category=$db->select($query);
if($category){
    while($result=$category->fetch_assoc())
    {
        
    
?>
<li><a href="posts.php ?id=<?php echo $result['id'];?>"> <?php echo $result['name'];?></a> 
            
    </li>
                <?php }
}
else{?>
    
    <li> NO Category </li>
<?php  }?>
</ul>
            </div>
            
            <div class="semiside border clear">
                <h2>Latest Articles</h2>
                <?php

$query= "select * from tbl_post limit 5";
$category=$db->select($query);
if($category){
    while($result=$category->fetch_assoc())
    {
        
    
?>
<div class="popular clear">
<h3><a href="post.php ?id=<?php echo $result['id'];?>"> <?php echo $result['title'];?></a> </h3>
<a href="post.php ?id=<?php echo $result['id'];?>"><img src="admin/<?php echo $result['image'];?>" alt="Image" /> </a>
            
<?php echo $fm->txtshorten($result['body'],120);?>
    </div>
                <?php }
}
else{
    header("Location:404.php");
}
?>  
            </div>
        </div>








       