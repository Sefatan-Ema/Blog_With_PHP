<?php include "included/header.php"; ?>
	<?php
if(!isset($_GET['pageid'])|| $_GET['pageid']==null){
    header("location:404.php");
}
else{
    $id=$_GET['pageid'];
}
?>
<?php
                                $pagequery="Select * from tbl_page where id='$id' ";
                                $pages=$db->select($pagequery);
                                if($pages)
                                {
                                    while($result=$pages->fetch_assoc())
                                    {

                                ?>
	<div class="content template clear">
		<div class="mainbody clear">
			<div class="about">
			
                     
				<h2><?php echo $result['name'];?></h2>
				<?php echo $result['body'];?>
					<?php
	}
} ?> </div>

		</div>
		<?php include 'included/sidebar.php'; ?>
    <?php include 'included/footer.php'; ?>